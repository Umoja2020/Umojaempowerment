<h1>Umoja</h1>
<hr>

<p>A Node.Js community based lending platform. Allowing users in a group to loan a particular amount of 
money. The users providing the amount can select the percentage of 
total amount they'll be contributing towards. </p.

<h2>To check the prototype:</h2>
<ol>
<li><code>git clone</code> the repository</li>
<li>Run <code>npm install</code>
<li>Run <code>node app.js</code>
</ol>
